package librairie;

//public class ClasseFille extends ClasseFinale { //* impossible car la classe mere est final

public class ClasseFille {
	
}
