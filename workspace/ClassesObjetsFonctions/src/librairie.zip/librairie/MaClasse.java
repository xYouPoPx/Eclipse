package librairie;

public class MaClasse {
	
	public static int uneVariable = 100;
	public static final int constante = 1000;
	
	public static void uneFonction(){
		System.out.println("uneFonction");
	}

}
